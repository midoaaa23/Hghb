
if (typeof gdjs.evtsExt__Collision3D__DistanceToPosition !== "undefined") {
  gdjs.evtsExt__Collision3D__DistanceToPosition.registeredGdjsCallbacks.forEach(callback =>
    gdjs._unregisterCallback(callback)
  );
}

gdjs.evtsExt__Collision3D__DistanceToPosition = {};
gdjs.evtsExt__Collision3D__DistanceToPosition.idToCallbackMap = new Map();
gdjs.evtsExt__Collision3D__DistanceToPosition.GDObjectObjects1= [];


gdjs.evtsExt__Collision3D__DistanceToPosition.userFunc0x1859590 = function GDJSInlineCode(runtimeScene, objects, eventsFunctionContext) {
"use strict";

if (objects.length > 0) {
    eventsFunctionContext.returnValue = gdjs._collision3DExtension.getDistanceToPosition(
        objects[0],
        eventsFunctionContext.getArgument("PositionX"),
        eventsFunctionContext.getArgument("PositionY"),
        eventsFunctionContext.getArgument("PositionZ"),
    );
}

};
gdjs.evtsExt__Collision3D__DistanceToPosition.eventsList0 = function(runtimeScene, eventsFunctionContext) {

{

gdjs.copyArray(eventsFunctionContext.getObjects("Object"), gdjs.evtsExt__Collision3D__DistanceToPosition.GDObjectObjects1);

const objects = gdjs.evtsExt__Collision3D__DistanceToPosition.GDObjectObjects1;
gdjs.evtsExt__Collision3D__DistanceToPosition.userFunc0x1859590(runtimeScene, objects, eventsFunctionContext);

}


};

gdjs.evtsExt__Collision3D__DistanceToPosition.func = function(runtimeScene, Object, PositionX, PositionY, PositionZ, parentEventsFunctionContext) {
let scopeInstanceContainer = null;
var eventsFunctionContext = {
  _objectsMap: {
"Object": Object
},
  _objectArraysMap: {
"Object": gdjs.objectsListsToArray(Object)
},
  _behaviorNamesMap: {
},
  globalVariablesForExtension: runtimeScene.getGame().getVariablesForExtension("Collision3D"),
  sceneVariablesForExtension: runtimeScene.getScene().getVariablesForExtension("Collision3D"),
  localVariables: [],
  getObjects: function(objectName) {
    return eventsFunctionContext._objectArraysMap[objectName] || [];
  },
  getObjectsLists: function(objectName) {
    return eventsFunctionContext._objectsMap[objectName] || null;
  },
  getBehaviorName: function(behaviorName) {
    return eventsFunctionContext._behaviorNamesMap[behaviorName] || behaviorName;
  },
  createObject: function(objectName) {
    const objectsList = eventsFunctionContext._objectsMap[objectName];
    if (objectsList) {
      const object = parentEventsFunctionContext && !(scopeInstanceContainer && scopeInstanceContainer.isObjectRegistered(objectName)) ?
        parentEventsFunctionContext.createObject(objectsList.firstKey()) :
        runtimeScene.createObject(objectsList.firstKey());
      if (object) {
        objectsList.get(objectsList.firstKey()).push(object);
        if (!(scopeInstanceContainer && scopeInstanceContainer.isObjectRegistered(objectName))) {
          eventsFunctionContext._objectArraysMap[objectName].push(object);
        }
      }
      return object;
    }
    return null;
  },
  getInstancesCountOnScene: function(objectName) {
    const objectsList = eventsFunctionContext._objectsMap[objectName];
    let count = 0;
    if (objectsList) {
      for(const objectName in objectsList.items)
        count += parentEventsFunctionContext && !(scopeInstanceContainer && scopeInstanceContainer.isObjectRegistered(objectName)) ?
parentEventsFunctionContext.getInstancesCountOnScene(objectName) :
        runtimeScene.getInstancesCountOnScene(objectName);
    }
    return count;
  },
  getLayer: function(layerName) {
    return runtimeScene.getLayer(layerName);
  },
  getArgument: function(argName) {
if (argName === "PositionX") return PositionX;
if (argName === "PositionY") return PositionY;
if (argName === "PositionZ") return PositionZ;
    return "";
  },
  getOnceTriggers: function() { return runtimeScene.getOnceTriggers(); }
};

gdjs.evtsExt__Collision3D__DistanceToPosition.GDObjectObjects1.length = 0;

gdjs.evtsExt__Collision3D__DistanceToPosition.eventsList0(runtimeScene, eventsFunctionContext);
gdjs.evtsExt__Collision3D__DistanceToPosition.GDObjectObjects1.length = 0;


return Number(eventsFunctionContext.returnValue) || 0;
}

gdjs.evtsExt__Collision3D__DistanceToPosition.registeredGdjsCallbacks = [];